package com.example.gblauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.role.RoleManager
import android.content.pm.PackageManager
import android.os.Build
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ResolveInfo
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {

    // Classic four-shade green palette
    private val C0 = 0xFF0F380F.toInt()
    private val C1 = 0xFF306230.toInt()
    private val C2 = 0xFF8BAC0F.toInt()
    private val C3 = 0xFF9BBC0F.toInt()
    private val BODY = 0xFFCDC9C0.toInt()
    private val BEZEL = 0xFF55556A.toInt()
    private val MAGENTA = 0xFF9A2257.toInt()
    private val PAD = 0xFF2B2B33.toInt()

    private val mono: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    private val handler = Handler(Looper.getMainLooper())
    private val iconCache = HashMap<String, Bitmap>()

    private var all: List<Entry> = emptyList()
    private var shown: List<Entry> = emptyList()
    private var selected = 0
    private var askedThisRun = false

    private lateinit var list: ListView
    private lateinit var adapter: AppAdapter
    private lateinit var clock: TextView
    private lateinit var info: TextView
    private lateinit var search: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BODY
        window.navigationBarColor = BODY
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        tick.run()
        askToBeDefault()
    }

    private fun isDefaultHome(): Boolean {
        val ri = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    private fun askToBeDefault() {
        val prefs = getSharedPreferences("gb", MODE_PRIVATE)
        if (isDefaultHome() || prefs.getBoolean("skipDefault", false) || askedThisRun) return
        askedThisRun = true
        AlertDialog.Builder(this)
            .setTitle("SET AS HOME?")
            .setMessage("Make DMG Launcher your default home screen.")
            .setPositiveButton("YES") { _, _ ->
                try {
                    val rm = getSystemService(RoleManager::class.java)
                    if (Build.VERSION.SDK_INT >= 29 && rm.isRoleAvailable(RoleManager.ROLE_HOME))
                        startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 7)
                    else startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                } catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
            .setNegativeButton("LATER", null)
            .setNeutralButton("DON'T ASK") { _, _ -> prefs.edit().putBoolean("skipDefault", true).apply() }
            .show()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Home pressed: reset to top
        if (search.visibility == View.VISIBLE) toggleSearch()
        selected = 0
        list.setSelection(0)
        adapter.notifyDataSetChanged()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (search.visibility == View.VISIBLE) toggleSearch() else moveTo(0)
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BODY)
            setPadding(dp(14), dp(14), dp(14), dp(10))
        }

        // Bezel + screen
        val bezel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(BEZEL); cornerRadii = floatArrayOf(
                    dp(10).toFloat(), dp(10).toFloat(), dp(10).toFloat(), dp(10).toFloat(),
                    dp(40).toFloat(), dp(40).toFloat(), dp(10).toFloat(), dp(10).toFloat())
            }
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        val bezelLabel = tv("DOT MATRIX WITH STEREO SOUND", 9f, 0xFFB0B0C0.toInt()).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.1f
        }
        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C3)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), 0, dp(4), dp(4))
        }
        clock = tv("--:--", 20f, C0)
        info = tv("", 12f, C0).apply { gravity = Gravity.END }
        header.addView(clock, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        screen.addView(header)
        screen.addView(View(this).apply { setBackgroundColor(C0) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)))

        // Search (hidden until SELECT)
        search = EditText(this).apply {
            typeface = mono; textSize = 16f; setTextColor(C0); setHintTextColor(C1)
            hint = "SEARCH>"; setBackgroundColor(C2); setSingleLine()
            setPadding(dp(8), dp(4), dp(8), dp(4)); visibility = View.GONE
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { applyFilter() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            setOnEditorActionListener { _, _, _ -> launchSelected(); true }
        }
        screen.addView(search)

        // List
        adapter = AppAdapter()
        list = ListView(this).apply {
            divider = null; setSelector(android.R.color.transparent)
            this.adapter = this@MainActivity.adapter
            isVerticalScrollBarEnabled = false
            setOnItemClickListener { _, _, pos, _ -> selected = pos; launchSelected() }
            setOnItemLongClickListener { _, _, pos, _ -> selected = pos; shown[pos].ri?.let { appMenu(it) }; true }
        }
        screen.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        bezel.addView(bezelLabel)
        bezel.addView(screen, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            .apply { topMargin = dp(8) })
        root.addView(bezel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Controls
        val controls = RelativeLayout(this)
        val dpad = dpad()
        controls.addView(dpad, RelativeLayout.LayoutParams(dp(110), dp(110)).apply {
            addRule(RelativeLayout.ALIGN_PARENT_LEFT); addRule(RelativeLayout.CENTER_VERTICAL)
            leftMargin = dp(8)
        })
        val ab = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bBtn = round("B", 54) { onBackPressed() }.also { (it.layoutParams as? LinearLayout.LayoutParams) }
        val aBtn = round("A", 54) { launchSelected() }
        ab.addView(bBtn, LinearLayout.LayoutParams(dp(54), dp(54)).apply { topMargin = dp(26) })
        ab.addView(aBtn, LinearLayout.LayoutParams(dp(54), dp(54)).apply { leftMargin = dp(12) })
        controls.addView(ab, RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, dp(90)).apply {
            addRule(RelativeLayout.ALIGN_PARENT_RIGHT); addRule(RelativeLayout.CENTER_VERTICAL)
            rightMargin = dp(8)
        })
        val pills = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
        }
        pills.addView(pill("SELECT") { toggleSearch() })
        pills.addView(pill("START") {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(18) })
        controls.addView(pills, RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            addRule(RelativeLayout.CENTER_HORIZONTAL); addRule(RelativeLayout.ALIGN_PARENT_BOTTOM)
        })
        root.addView(controls, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(150)).apply { topMargin = dp(10) })

        setContentView(root)
    }

    private fun tv(t: String, size: Float, color: Int) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); typeface = mono
    }

    private fun round(label: String, size: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; setTextColor(0xFFE8B6CC.toInt()); typeface = mono
        gravity = Gravity.CENTER
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(MAGENTA) }
        setOnClickListener { onClick() }
    }

    private fun pill(label: String, onClick: () -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        box.addView(TextView(this).apply {
            background = GradientDrawable().apply { setColor(0xFF8A8A92.toInt()); cornerRadius = dp(10).toFloat() }
            setOnClickListener { onClick() }
        }, LinearLayout.LayoutParams(dp(54), dp(16)))
        box.addView(tv(label, 9f, BEZEL).apply { gravity = Gravity.CENTER })
        return box
    }

    private fun dpad(): View {
        val g = GridLayout(this).apply { rowCount = 3; columnCount = 3 }
        fun cell(txt: String?, act: (() -> Unit)?): View = TextView(this).apply {
            text = txt ?: ""; textSize = 12f; setTextColor(0xFF77778A.toInt()); gravity = Gravity.CENTER
            setBackgroundColor(if (txt != null || act == null) PAD else PAD)
            if (act != null) setOnClickListener { act() }
        }
        val lp = { GridLayout.LayoutParams().apply { width = dp(36); height = dp(36) } }
        val none = { View(this) }
        g.addView(none(), lp()); g.addView(cell("▲") { moveTo(selected - 1) }, lp()); g.addView(none(), lp())
        g.addView(cell("◀") { moveTo(selected - 5) }, lp()); g.addView(cell(null, null), lp())
        g.addView(cell("▶") { moveTo(selected + 5) }, lp())
        g.addView(none(), lp()); g.addView(cell("▼") { moveTo(selected + 1) }, lp()); g.addView(none(), lp())
        return g
    }

    // ---------- Data ----------
    private fun loadApps() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = packageManager
        val builtIns = listOf(
            Entry("Music", null, MusicActivity::class.java, Gb.NOTE),
            Entry("Video", null, VideoActivity::class.java, Gb.FILM))
        all = builtIns + pm.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { Entry(it.loadLabel(pm).toString(), it, null, null) }
            .sortedBy { it.label.lowercase() }
        applyFilter()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown = if (q.isEmpty()) all else all.filter { it.label.lowercase().contains(q) }
        selected = 0
        adapter.notifyDataSetChanged()
        list.setSelection(0)
        updateInfo()
    }

    private fun moveTo(i: Int) {
        if (shown.isEmpty()) return
        selected = i.coerceIn(0, shown.size - 1)
        adapter.notifyDataSetChanged()
        list.smoothScrollToPosition(selected)
        updateInfo()
    }

    private fun launchSelected() {
        val e = shown.getOrNull(selected) ?: return
        if (e.target != null) { startActivity(Intent(this, e.target)); return }
        val intent = packageManager.getLaunchIntentForPackage(e.ri!!.activityInfo.packageName) ?: return
        startActivity(intent)
    }

    private fun toggleSearch() {
        if (search.visibility == View.VISIBLE) {
            search.setText(""); search.visibility = View.GONE
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .hideSoftInputFromWindow(search.windowToken, 0)
        } else {
            search.visibility = View.VISIBLE; search.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .showSoftInput(search, 0)
        }
    }

    private fun appMenu(ri: ResolveInfo) {
        val pkg = ri.activityInfo.packageName
        val name = ri.loadLabel(packageManager).toString()
        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(arrayOf("App info", "Uninstall")) { _, which ->
                if (which == 0) startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$pkg")))
                else startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
            }.show()
    }

    // ---------- Header ----------
    private val tick = object : Runnable {
        override fun run() {
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            updateInfo()
            handler.postDelayed(this, 15000)
        }
    }

    private fun updateInfo() {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (lvl >= 0) lvl * 100 / scale else 0
        val bars = (pct / 25).coerceIn(0, 4)
        val batt = "[" + "■".repeat(bars) + "□".repeat(4 - bars) + "]"
        info.text = "${if (shown.isEmpty()) 0 else selected + 1}/${shown.size}  $batt"
    }

    // ---------- Keys ----------
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> { moveTo(selected - 1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { moveTo(selected + 1); return true }
            KeyEvent.KEYCODE_DPAD_CENTER -> { launchSelected(); return true }
            KeyEvent.KEYCODE_VOLUME_UP -> { moveTo(selected - 1); return true }
            KeyEvent.KEYCODE_VOLUME_DOWN -> { moveTo(selected + 1); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- 4-shade pixel icons ----------
    private fun gbIcon(key: String, d: Drawable): Bitmap = iconCache.getOrPut(key) {
        val n = 24
        val src = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, n, n); d.draw(Canvas(src))
        val px = IntArray(n * n)
        src.getPixels(px, 0, n, 0, 0, n, n)
        for (i in px.indices) {
            val c = px[i]
            val a = c ushr 24
            px[i] = if (a < 80) C3 else {
                val lum = 0.30 * Color.red(c) + 0.59 * Color.green(c) + 0.11 * Color.blue(c)
                when {
                    lum < 70 -> C0
                    lum < 140 -> C1
                    lum < 210 -> C2
                    else -> C3
                }
            }
        }
        val small = Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
        Bitmap.createScaledBitmap(small, n * 4, n * 4, false) // nearest-neighbour
    }

    inner class AppAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
            val row = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), dp(5), dp(6), dp(5))
                addView(TextView(context), LinearLayout.LayoutParams(dp(18), ViewGroup.LayoutParams.WRAP_CONTENT))
                addView(ImageView(context), LinearLayout.LayoutParams(dp(30), dp(30)))
                addView(TextView(context).apply {
                    typeface = mono; textSize = 16f; setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
            }
            val e = shown[p]
            val sel = p == selected
            val fg = if (sel) C3 else C0
            row.setBackgroundColor(if (sel) C0 else C3)
            (row.getChildAt(0) as TextView).apply { text = if (sel) "▶" else ""; setTextColor(fg); typeface = mono }
            (row.getChildAt(1) as ImageView).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setImageBitmap(if (e.glyph != null) Gb.glyph(e.glyph)
                    else gbIcon(e.ri!!.activityInfo.packageName, e.ri.loadIcon(packageManager)))
            }
            (row.getChildAt(2) as TextView).apply {
                text = e.label.uppercase(); setTextColor(fg)
            }
            return row
        }
    }
}
